# Phase 3: Application Tracking
**Duration:** 4-5 days | **Commit Tag:** `v0.4.0-tracker`

## Objective
Build Application Tracker with Interview Memory Bank and Thank-You email generation.

## Tasks

### Database
- [ ] Create `applications` table
- [ ] Create `application_stages` table
- [ ] Create `generated_emails` table
- [ ] Create `reminders` table
- [ ] Add indexes for user + status queries

### Application CRUD
- [ ] `GET /api/applications` - List (with filters)
- [ ] `POST /api/applications` - Create
- [ ] `GET /api/applications/[id]` - Get with stages
- [ ] `PUT /api/applications/[id]` - Update
- [ ] `DELETE /api/applications/[id]` - Delete
- [ ] `PUT /api/applications/[id]/status` - Update status

### Stage Management
- [ ] `POST /api/applications/[id]/stages` - Add stage
- [ ] `PUT /api/applications/stages/[id]` - Update stage
- [ ] `DELETE /api/applications/stages/[id]` - Delete stage

### Memory Bank (Interview Notes)
- [ ] `POST /api/applications/stages/[id]/notes` - Process raw notes
- [ ] AI structuring (topics, questions, signals, concerns)
- [ ] Store both raw_notes and ai_structured

### Email Generation
- [ ] `POST /api/applications/stages/[id]/email` - Generate email
- [ ] Thank-you email prompt
- [ ] Follow-up email prompt
- [ ] Store generated emails

### Reminders
- [ ] Reminder scheduling logic
- [ ] Types: follow_up (7 days), status_check (14 days)
- [ ] Reminder API endpoints

### UI Components
- [ ] ApplicationTracker.tsx (main view)
- [ ] KanbanBoard.tsx (drag-drop columns)
- [ ] ApplicationList.tsx (table view)
- [ ] ApplicationCard.tsx
- [ ] ApplicationForm.tsx
- [ ] StageTimeline.tsx
- [ ] InterviewNotesInput.tsx
- [ ] StructuredNotes.tsx (AI summary)
- [ ] EmailPreview.tsx
- [ ] ReminderList.tsx

### Pages
- [ ] `/dashboard/applications` - Main tracker
- [ ] `/dashboard/applications/[id]` - Application detail
- [ ] `/dashboard/applications/new` - Add application

## Key Files to Create

```
app/(dashboard)/applications/
  page.tsx
  [id]/page.tsx
  new/page.tsx
  _components/
    KanbanBoard.tsx
    ApplicationList.tsx
    ApplicationCard.tsx
    ApplicationForm.tsx
    StageTimeline.tsx
    StageForm.tsx
    InterviewNotesInput.tsx
    StructuredNotes.tsx
    EmailPreview.tsx
    EmailEditor.tsx
    ReminderList.tsx
    
app/api/applications/
  route.ts
  [id]/route.ts
  [id]/status/route.ts
  [id]/stages/route.ts
  stages/[id]/route.ts
  stages/[id]/notes/route.ts
  stages/[id]/email/route.ts

lib/ai/prompts/
  structure-notes.ts
  thank-you-email.ts
  follow-up-email.ts
```

## Status Pipeline

```typescript
const STATUSES = [
  'saved',      // Saved, not applied
  'applied',    // Application submitted
  'screening',  // Initial review
  'phone',      // Phone interview
  'technical',  // Technical round
  'onsite',     // Onsite/final round
  'offer',      // Received offer
  'accepted',   // Accepted offer
  'declined',   // Declined offer
  'rejected',   // They rejected
  'ghosted',    // No response 21+ days
  'withdrawn'   // You withdrew
];
```

## Note Structuring Prompt

```typescript
const STRUCTURE_NOTES_PROMPT = `
Process interview notes into structured data.

RAW NOTES: {raw_notes}
COMPANY: {company}
INTERVIEWER: {interviewer}

Return JSON:
{
  topics_discussed: [],
  questions_asked: [],
  your_answers_summary: [],
  their_concerns: [],
  positive_signals: [],
  next_steps: "",
  follow_up_points: []
}
`;
```

## Thank-You Email Prompt

```typescript
const THANK_YOU_PROMPT = `
Write thank-you email based on interview.

NOTES: {structured_notes}
CANDIDATE: {name}
INTERVIEWER: {interviewer}

Reference specific discussion points.
Address any concerns raised.
Professional but warm. Under 200 words.

Return: { subject, body }
`;
```

## Tests
- [ ] Application CRUD works
- [ ] Kanban drag-drop updates status
- [ ] Notes structure correctly
- [ ] Thank-you emails are personalized
- [ ] Reminders schedule correctly

## Done When
- [ ] Can track applications end-to-end
- [ ] Kanban and list views work
- [ ] Interview notes auto-structure
- [ ] Thank-you emails generate from notes
- [ ] Reminders appear on schedule
- [ ] All tests passing
