# Phase Manager Skill

A generic skill for managing phased software development projects efficiently.

## Purpose

This skill helps Claude Code:
- Execute multi-phase projects systematically
- Track progress and token usage
- Self-review work between phases
- Maintain efficiency across long builds

## When to Use

Use this skill when:
- Building a project in multiple phases
- You need confirmation between phases
- You want to track token efficiency
- The project has a phase-specific instruction file

## Required Project Structure

Your project should have phase files in one of these locations:
```
.claude/phases/PHASE0.md
.claude/phases/PHASE1.md
...
```
OR in a project-specific skill:
```
/mnt/skills/user/[project]/PHASE0.md
/mnt/skills/user/[project]/PHASE1.md
...
```

## Phase File Format

Each phase file should follow this structure:
```markdown
# Phase X: [Name]
Duration: [estimate]
Commit Tag: vX.X.X-name

## Objective
[One sentence goal]

## Tasks
- [ ] Task 1
- [ ] Task 2
...

## Files to Create/Modify
- path/to/file.ts - description

## Tests Required
- [ ] Test 1
- [ ] Test 2

## Done When
- [ ] Criteria 1
- [ ] Criteria 2
```

## Protocol

### Phase Start
```
1. Read current phase file ONLY (not all phases)
2. Announce: "Starting Phase X: [Name]"
3. List tasks to complete
4. Begin work
```

### During Phase
```
1. Complete tasks sequentially
2. Commit frequently with descriptive messages
3. Run tests after significant changes
4. Track any blockers or questions
```

### Phase End Protocol

When all tasks complete, execute this EXACTLY:

```
╔═══════════════════════════════════════════════════════════════╗
║                    PHASE [X] COMPLETE                         ║
║                    [Phase Name]                               ║
╚═══════════════════════════════════════════════════════════════╝

📋 SUMMARY
──────────────────────────────────────────────────────────────────
Tasks completed: X/X
Files created:
  - path/to/file1.ts
  - path/to/file2.tsx
Files modified:
  - path/to/existing.ts
Tests: X passing, X failing

✅ SELF-REVIEW CHECKLIST
──────────────────────────────────────────────────────────────────
[✓] All tasks from phase file completed
[✓] No hardcoded secrets or credentials  
[✓] Error handling in place
[✓] Types are correct (no `any` without reason)
[✓] No console.logs left (except intentional)
[✓] Code follows project conventions
[✓] Database migrations tested

⚠️  ISSUES ENCOUNTERED
──────────────────────────────────────────────────────────────────
[List any problems and how resolved, or "None"]

📊 TOKEN USAGE
──────────────────────────────────────────────────────────────────
Estimated tokens this phase: ~X,XXX
Calculation:
  - Messages exchanged: X × ~500 = X,XXX
  - Code generated: ~X,XXX chars ÷ 4 = X,XXX
  - Files read: ~X,XXX chars ÷ 4 = X,XXX
  - Total: ~X,XXX tokens

Efficiency notes:
  - [Any observations about token usage]
  - [Suggestions for next phase]

🔀 GIT STATUS  
──────────────────────────────────────────────────────────────────
Branch: phase-X-[name]
Commits this phase: X
Ready to merge and tag: vX.X.X-[phase-name]

╔═══════════════════════════════════════════════════════════════╗
║              ⏳ AWAITING APPROVAL TO CONTINUE                 ║
╚═══════════════════════════════════════════════════════════════╝

Please respond:
  "continue"     → Merge, tag, proceed to Phase [X+1]
  "fix [issue]"  → Address specific issue first
  "pause"        → Stop here, will resume later
```

### Efficiency Rules

1. **Read Only What's Needed**
   - Load current phase file, not all phases
   - Load schema only when doing DB work
   - Load prompts only when doing AI work

2. **Don't Re-read Files**
   - If you've read a file this session, reference from memory
   - Exception: If file was modified, re-read it

3. **Batch Operations**
   - Create multiple related files before testing
   - Run all tests at once, not one-by-one
   - Commit related changes together

4. **Minimize Output**
   - Don't echo file contents after creating
   - Don't explain code that's self-documenting
   - Use terse commit messages

5. **Track Token Usage**
   - Estimate tokens at phase end
   - Formula: ~4 chars = 1 token
   - Include in phase summary

## Commit Convention

```
feat: add [feature]        # New feature
fix: resolve [issue]       # Bug fix
refactor: improve [area]   # Code improvement
test: add tests for [x]    # Test additions
docs: update [doc]         # Documentation
chore: [task]              # Maintenance
```

Phase completion commit:
```
feat: complete phase X - [phase name]

- Task 1 done
- Task 2 done
- Tests passing
```

Then tag:
```bash
git tag vX.X.X-phase-name
```

## Integration with Other Skills

This skill works well with:
- `code-review` - Use for self-review checklist
- `sql-migration` - Use for database changes
- `typescript-codegen` - Use for type generation

## Token Tracking Helper

To estimate tokens used:
```
Messages sent × ~500 (avg tokens/message)
+ Code generated × 0.25 (chars to tokens)
+ Files read × 0.25 (chars to tokens)
= Approximate tokens
```

Report this at phase end for efficiency monitoring.
