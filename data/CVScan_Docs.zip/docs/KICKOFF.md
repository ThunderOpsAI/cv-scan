# BulletPro - Claude Code Kickoff Guide

## One-Time Setup

### Step 1: Move skills
```bash
cp -r skills/phase-manager/ /mnt/skills/user/phase-manager/
cp -r skills/bulletpro/ /mnt/skills/user/bulletpro/
```

### Step 2: Add CLAUDE.md to project
```bash
# If .claude/ doesn't exist, create it
mkdir -p /path/to/bullet-pro/.claude

# Copy the project instructions
cp CLAUDE.md /path/to/bullet-pro/CLAUDE.md
```

> **Note:** Claude Code looks for `CLAUDE.md` in the project root OR `.claude/` directory.

### Step 3: Verify
```
/mnt/skills/user/
├── phase-manager/
│   └── SKILL.md
├── bulletpro/
│   ├── SKILL.md
│   ├── EXISTING.md
│   ├── PHASE0.md through PHASE7.md
│   ├── SCHEMA_ADDITIONS.sql
│   ├── PROMPTS.ts
│   └── CONVENTIONS.md

/path/to/bullet-pro/
├── CLAUDE.md    ← Claude Code reads this on startup
├── app/
├── lib/
└── ... (existing project)
```

---

## Starting Phase 0

Open Claude Code in the BulletPro project root. Paste this:

```
Read the skills at:
1. /mnt/skills/user/phase-manager/SKILL.md
2. /mnt/skills/user/bulletpro/SKILL.md
3. /mnt/skills/user/bulletpro/EXISTING.md

Then start Phase 0. Read /mnt/skills/user/bulletpro/PHASE0.md for tasks.
Follow the phase-manager protocol. Commit frequently.
After the phase is complete, show the full completion summary with token estimate and wait for my approval.
```

---

## After Phase Completion

Claude Code will display a completion summary. Respond with one of:

### ✅ Approve and continue
```
Looks good. Merge, tag, and start Phase [NEXT]. Read /mnt/skills/user/bulletpro/PHASE[NEXT].md
```

### 🔧 Fix something first
```
Before continuing, fix: [describe issue]
```

### ⏸️ Pause
```
Pause here. I'll resume later.
```

---

## Resuming a Later Session

If you start a new Claude Code session:

```
Read CLAUDE.md and the skills at:
1. /mnt/skills/user/phase-manager/SKILL.md
2. /mnt/skills/user/bulletpro/SKILL.md
3. /mnt/skills/user/bulletpro/EXISTING.md

Phases 0 through [X] are complete. Start Phase [X+1].
Read /mnt/skills/user/bulletpro/PHASE[X+1].md for tasks.
Follow the phase-manager protocol.
```

---

## Course Corrections

If Claude Code starts rebuilding existing features:
```
Stop. Re-read /mnt/skills/user/bulletpro/EXISTING.md. You're rebuilding something that exists. Only build what's in the current phase file.
```

If Claude Code reads too many files:
```
Stop. Too many files loaded. For this phase you only need PHASE[X].md. Load SCHEMA_ADDITIONS.sql only for DB work, PROMPTS.ts only for AI work.
```

If Claude Code is too verbose:
```
Be more concise. Write code and commit. Don't explain self-documenting code.
```

---

## Token Tracking

Fill in after each phase:

| Phase | Tokens | Duration | Notes |
|-------|--------|----------|-------|
| 0 | | | |
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |
| 5 | | | |
| 6 | | | |
| 7 | | | |
| **Total** | | | |

Target: 15-30K tokens per phase. Flag anything over 50K.
