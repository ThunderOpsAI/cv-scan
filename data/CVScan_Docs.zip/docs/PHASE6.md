# Phase 6: Growth & Viral
**Duration:** 4-5 days | **Commit Tag:** `v0.7.0-growth`

## Objective
Build public ATS scanner, Resume Roast, referral system, and SEO pages.

## Tasks

### Public ATS Scanner (No Auth)
- [ ] `POST /api/public/ats-scan` - Anonymous scan
- [ ] `GET /api/public/ats/[token]` - View results
- [ ] IP-based rate limiting (5/day)
- [ ] Limited results (score + top 3 gaps)
- [ ] Signup CTA for full results
- [ ] Shareable result pages
- [ ] OG image generation for social sharing

### Resume Roast
- [ ] `POST /api/public/roast` - Generate roast
- [ ] `GET /api/public/roast/[token]` - View roast
- [ ] Roast prompt (humorous but helpful)
- [ ] Grade A-F with tagline
- [ ] Rate limiting (3/day per IP)
- [ ] Shareable roast cards

### Referral System
- [ ] Generate unique referral codes per user
- [ ] `GET /api/referrals/code` - Get user's code
- [ ] `GET /api/referrals/stats` - Get referral stats
- [ ] `POST /api/referrals/track` - Track clicks
- [ ] Referral cookie (30 day)
- [ ] Credit on referee's first purchase (5 credits to referrer)
- [ ] Bonus credits to referee (3 extra)
- [ ] Referral dashboard UI

### SEO Pages
- [ ] Industry pages template: `/resume-tips/[industry]`
- [ ] Job title pages template: `/resume-examples/[job-title]`
- [ ] Generate 20 initial pages
- [ ] SEO metadata
- [ ] Internal linking
- [ ] CTA to scanner/signup

### Landing Page Updates
- [ ] Add public scanner section
- [ ] Add roast CTA
- [ ] Social proof (testimonials placeholder)
- [ ] Referral mention

## Key Files to Create

```
app/(public)/
  tools/
    ats-checker/page.tsx      # Public scanner
  score/[token]/page.tsx       # Shareable result
  roast/page.tsx               # Roast input
  roast/[token]/page.tsx       # Shareable roast
  resume-tips/[industry]/page.tsx
  resume-examples/[job-title]/page.tsx

app/api/public/
  ats-scan/route.ts
  ats/[token]/route.ts
  roast/route.ts
  roast/[token]/route.ts
  
app/api/referrals/
  code/route.ts
  stats/route.ts
  track/route.ts
  
app/(dashboard)/referrals/
  page.tsx
  _components/
    ReferralLink.tsx
    ReferralStats.tsx
    ShareButtons.tsx
    
lib/og/
  score-card.tsx    # OG image for scores
  roast-card.tsx    # OG image for roasts
  
lib/rate-limit/
  ip-limiter.ts

lib/seo/
  pages-data.ts     # SEO page content
  generate-page.ts  # Page generation
```

## Public Scanner Flow

```
1. User lands on /tools/ats-checker
2. Pastes resume + job description
3. Submits (no login required)
4. Gets: Score, top 3 gaps, recommendations teaser
5. CTA: "Sign up free to see all 12 gaps"
6. Share button generates /score/[token] link
```

## Rate Limiting

```typescript
// lib/rate-limit/ip-limiter.ts
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';

const ratelimit = new Ratelimit({
  redis: Redis.fromEnv(),
  limiter: Ratelimit.slidingWindow(5, '24 h'),
});

export async function checkRateLimit(ip: string, type: string) {
  const { success, remaining } = await ratelimit.limit(`${type}:${ip}`);
  return { allowed: success, remaining };
}
```

## Roast Prompt

```typescript
const ROAST_PROMPT = `
Roast this resume humorously but helpfully.

RESUME: {resume_text}

Return JSON:
{
  grade: "A-F",
  tagline: "Witty one-liner about this resume",
  good: ["3 genuine positives"],
  bad: ["3 problems"],
  ugly: ["2-3 brutal but fair observations"],
  verdict: "2-3 sentence summary",
  cta: "Constructive call to action"
}

Rules:
- Be funny but not mean
- Don't mock personal details
- Focus on writing quality, not career choices
- End constructively
`;
```

## Referral Logic

```typescript
// On signup, check for referral cookie
const referralCode = cookies().get('ref')?.value;
if (referralCode) {
  await trackReferralSignup(referralCode, newUserId);
  await addBonusCredits(newUserId, 3); // Referee bonus
}

// On first purchase
if (user.referred_by) {
  await awardReferrerCredits(user.referred_by, 5);
}
```

## SEO Page Data Structure

```typescript
// lib/seo/pages-data.ts
export const industryPages = [
  { slug: 'technology', title: 'Tech Resume Tips' },
  { slug: 'healthcare', title: 'Healthcare Resume Tips' },
  { slug: 'finance', title: 'Finance Resume Tips' },
  // ... 15 more
];

export const jobTitlePages = [
  { slug: 'software-engineer', title: 'Software Engineer Resume' },
  { slug: 'product-manager', title: 'Product Manager Resume' },
  // ... 20 more
];
```

## Tests
- [ ] Public scan works without auth
- [ ] Rate limiting blocks after 5/day
- [ ] Shareable URLs work
- [ ] Roast generates funny content
- [ ] Referral codes generate uniquely
- [ ] Referral tracking works
- [ ] SEO pages render correctly
- [ ] OG images generate

## Done When
- [ ] Public ATS scanner live at /tools/ats-checker
- [ ] Resume roast working
- [ ] Shareable score/roast pages
- [ ] Referral system active
- [ ] 20 SEO pages published
- [ ] All rate limiting working
- [ ] All tests passing
