# Phase 2: Job Pack System
**Duration:** 5-6 days | **Commit Tag:** `v0.3.0-jobpacks`

## Objective
Build ATS Scanner with Tailor-Diff visualization and Cultural Alignment scoring.

## Tasks

### Database
- [ ] Create `job_packs` table
- [ ] Create `ats_scans` table (for standalone scans)
- [ ] Add indexes for user queries

### ATS Scanner
- [ ] `POST /api/ats/scan` - Full ATS scan
- [ ] `GET /api/ats/scan/[id]` - Get scan results
- [ ] `POST /api/ats/scan/[id]/share` - Generate share token
- [ ] Keyword extraction (found, missing, emphasize)
- [ ] Score calculation (hard skills, soft skills, experience, education)
- [ ] Free scan tracking (3/day per user)
- [ ] 1 credit after free limit

### Cultural Alignment
- [ ] Tone detection prompt
- [ ] Candidate tone analysis
- [ ] Mismatch warnings
- [ ] Adjustment suggestions

### Tailor-Diff
- [ ] Diff computation logic
- [ ] Track keywords integrated
- [ ] Track tone adjustments
- [ ] Before/after score comparison

### Job Pack Generation
- [ ] `POST /api/job-packs` - Create job pack
- [ ] `GET /api/job-packs/[id]` - Get pack
- [ ] `GET /api/job-packs/[id]/diff` - Get tailor diff
- [ ] `GET /api/job-packs/[id]/export/[format]` - PDF/DOCX export
- [ ] Tailored bullet generation
- [ ] Cover letter generation
- [ ] Pack bundling (5 credits complete)

### UI Components
- [ ] ATSScanner.tsx (main interface)
- [ ] ScoreGauge.tsx (visual score)
- [ ] KeywordList.tsx (found/missing/emphasize)
- [ ] CulturalWarnings.tsx
- [ ] TailorDiff.tsx (side-by-side view)
- [ ] JobPackWizard.tsx (creation flow)
- [ ] PackTypeSelector.tsx (quick/complete options)

### Pages
- [ ] `/dashboard/scanner` - ATS scanner
- [ ] `/dashboard/job-packs` - List packs
- [ ] `/dashboard/job-packs/[id]` - View pack with diff
- [ ] `/dashboard/job-packs/new` - Create wizard

## Key Files to Create

```
app/(dashboard)/scanner/
  page.tsx
  _components/
    ATSScanner.tsx
    ScoreGauge.tsx
    KeywordList.tsx
    CulturalWarnings.tsx
    
app/(dashboard)/job-packs/
  page.tsx
  [id]/page.tsx
  new/page.tsx
  _components/
    JobPackWizard.tsx
    TailorDiff.tsx
    PackTypeSelector.tsx
    BulletList.tsx
    CoverLetterPreview.tsx
    ExportButtons.tsx
    
app/api/ats/
  scan/route.ts
  scan/[id]/route.ts
  scan/[id]/share/route.ts
  
app/api/job-packs/
  route.ts
  [id]/route.ts
  [id]/diff/route.ts
  [id]/export/[format]/route.ts

lib/ai/prompts/
  ats-analysis.ts
  cultural-analysis.ts
  bullet-tailoring.ts
  cover-letter.ts
  
lib/export/
  pdf.ts
  docx.ts
```

## ATS Analysis Prompt

```typescript
const ATS_PROMPT = `
Analyze job description for ATS optimization.

JOB: {job_description}
CANDIDATE: {profile_summary}

Return JSON:
{
  extracted: { title, company, years_required },
  keywords: {
    hard_skills: [{ skill, importance, found }],
    soft_skills: [{ skill, importance, found }],
    tools: [{ tool, importance, found }]
  },
  scores: { hard_skills, soft_skills, experience, education, overall },
  cultural: {
    detected_tone: "startup|corporate|academic|sales",
    tone_evidence: [],
    alignment_score,
    warnings: [],
    suggestions: []
  },
  recommendations: [{ priority, type, text }]
}
`;
```

## Tailor-Diff Structure

```typescript
interface TailorDiff {
  original_bullets: string[];
  tailored_bullets: string[];
  changes: {
    index: number;
    keywords_added: string[];
    tone_adjustments: string[];
  }[];
  summary: {
    keywords_integrated: number;
    keywords_total: number;
    score_before: number;
    score_after: number;
  };
}
```

## Tests
- [ ] ATS scores calculate correctly
- [ ] Cultural tone detects accurately
- [ ] Tailor-diff shows changes
- [ ] Free scan limit works
- [ ] Export generates valid files
- [ ] Credits charge correctly

## Done When
- [ ] Can scan any job description
- [ ] See ATS score with breakdown
- [ ] Cultural warnings appear when needed
- [ ] Tailor-diff shows what changed
- [ ] Can export to PDF/DOCX
- [ ] All tests passing
