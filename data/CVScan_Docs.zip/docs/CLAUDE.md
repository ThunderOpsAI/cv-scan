# BulletPro - Claude Code Instructions

## Project

BulletPro is a job search command center. You are adding new features to an EXISTING working application. The app already has auth, payments, credits, AI generation, email, and a landing page.

**DO NOT** rebuild, modify, or refactor any existing features unless explicitly asked.

## Skills to Read (Before Starting)

1. `/mnt/skills/user/bulletpro/SKILL.md` - Project entry point
2. `/mnt/skills/user/bulletpro/EXISTING.md` - What's already built (never rebuild these)
3. `/mnt/skills/user/phase-manager/SKILL.md` - Phase execution protocol

Then read ONLY the current phase file when told which phase to work on.

## Efficiency Rules

- **One phase at a time.** Only read that phase's file.
- **Don't read all phases.** Wastes tokens.
- **Don't re-read files** you've already loaded this session.
- **Load SCHEMA_ADDITIONS.sql** only when doing database work.
- **Load PROMPTS.ts** only when implementing AI features.
- **Load CONVENTIONS.md** only if unsure about code style.
- **Commit frequently.** Don't accumulate a huge diff.
- **Don't explain self-documenting code.** Just write it.
- **Batch related changes.** Create multiple files before testing.

## Phase Protocol

```
START:  Read current phase file → Announce tasks → Begin work
DURING: Build features → Commit often → Test after changes
END:    Show completion summary → Report token usage → WAIT for approval
```

Always wait for "continue", "fix [issue]", or "pause" before proceeding.

## Integration Points (Use These, Don't Rebuild)

```typescript
// Auth
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

// Credits
import { deductCredit } from '@/lib/supabase/credits';

// Database
import { createClient } from '@/lib/supabase/server';

// AI
import { generateWithGemini } from '@/lib/ai/gemini';
```

## New Files Go Here

```
app/(dashboard)/[feature]/page.tsx         # Pages
app/(dashboard)/[feature]/_components/     # Components
app/api/[feature]/route.ts                 # API routes
lib/ai/prompts/[name].ts                   # AI prompts
types/[feature].ts                         # Types
```

## Stack

Next.js App Router, TypeScript, Tailwind, Supabase, Stripe, Gemini AI, Resend, Zod

## Commits

```
feat: add [feature]     fix: resolve [issue]     refactor: improve [area]
```

Phase end: `git tag vX.X.X-phase-name`
