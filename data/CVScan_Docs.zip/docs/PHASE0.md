# Phase 0: Foundation
**Duration:** 3-4 days | **Commit Tag:** `v0.1.0-foundation`

## Objective
Set up Master Profile system with Metric Mining agent and update credit system.

## Tasks

### Database
- [ ] Create `profiles` table (extends auth users)
- [ ] Create `experiences` table
- [ ] Create `bullets` table (with mined_metrics JSONB)
- [ ] Create `education` table
- [ ] Create `skills` table
- [ ] Create `star_stories` table
- [ ] Add RLS policies for all new tables
- [ ] Create `calculate_profile_strength()` function

### API Routes
- [ ] `GET/PUT /api/profile` - Get/update profile
- [ ] `POST/PUT/DELETE /api/profile/experiences` - CRUD experiences
- [ ] `POST/PUT/DELETE /api/profile/bullets` - CRUD bullets
- [ ] `POST /api/profile/mine-metrics` - Metric mining endpoint
- [ ] `GET /api/profile/strength` - Get profile strength score

### Metric Mining
- [ ] Create prompt in `lib/ai/prompts/metric-mining.ts`
- [ ] Mining flow: raw bullet → AI questions → user answers → enhanced bullet
- [ ] Store both raw_text and enhanced_text in bullets table

### UI Components
- [ ] Profile setup wizard (multi-step)
- [ ] Experience form with bullet editor
- [ ] Metric mining dialog (AI asks questions)
- [ ] Profile strength indicator
- [ ] Skills manager

### Pages
- [ ] `/dashboard/profile` - Main profile page
- [ ] `/dashboard/profile/experience` - Experience editor
- [ ] `/dashboard/profile/education` - Education editor  
- [ ] `/dashboard/profile/skills` - Skills manager

## Key Files to Create

```
app/(dashboard)/profile/
  page.tsx
  _components/
    ProfileWizard.tsx
    ExperienceCard.tsx
    ExperienceForm.tsx
    BulletEditor.tsx
    MetricMiningDialog.tsx
    ProfileStrength.tsx
    SkillsManager.tsx
  _actions/
    profile.ts
    experiences.ts
    bullets.ts
    
lib/ai/prompts/
  metric-mining.ts

types/
  profile.ts
```

## Metric Mining Prompt

```typescript
const MINING_QUESTIONS_PROMPT = `
Given this resume bullet: "{bullet}"

Ask 2-3 specific questions to extract metrics:
- Numbers (team size, users, revenue, percentages)
- Timeframes (duration, deadlines)
- Comparisons (before/after, vs benchmark)

Return JSON: { questions: string[] }
`;

const ENHANCE_BULLET_PROMPT = `
Original: "{raw_bullet}"
User provided: {answers}

Rewrite as XYZ format: "Accomplished [X] measured by [Y] by doing [Z]"
Include all metrics naturally. Strong action verb.

Return JSON: { 
  enhanced_text: string,
  skills: string[],
  metrics: object 
}
`;
```

## Tests
- [ ] Profile CRUD operations work
- [ ] Metric mining generates questions
- [ ] Enhanced bullets save correctly
- [ ] Profile strength calculates correctly
- [ ] RLS policies restrict access properly

## Done When
- [ ] User can create full profile with experiences
- [ ] Metric mining improves bullet quality
- [ ] Profile strength shows completion %
- [ ] All CRUD operations working
- [ ] Tests passing
