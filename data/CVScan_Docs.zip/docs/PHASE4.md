# Phase 4: Interview & Salary
**Duration:** 5-6 days | **Commit Tag:** `v0.5.0-interview`

## Objective
Build Interview Practice Chatbot, Salary Intelligence, and Application Q&A.

## Tasks

### Database
- [ ] Create `interview_preps` table (if not exists)
- [ ] Add practice_count, last_practiced fields
- [ ] Create `practice_sessions` table (optional, for history)

### Interview Prep Generation
- [ ] `POST /api/interview-prep` - Generate prep (3 credits)
- [ ] `GET /api/interview-prep/[id]` - Get prep
- [ ] Generates: questions, STAR suggestions, company brief, talking points

### Interview Practice
- [ ] `POST /api/interview-prep/[id]/practice/start` - Start session
- [ ] `POST /api/interview-prep/[id]/practice/respond` - Submit answer
- [ ] `POST /api/interview-prep/[id]/practice/end` - End session
- [ ] Question generation by type (behavioral, technical, case)
- [ ] Response evaluation (STAR scoring)
- [ ] Session summary generation
- [ ] 1 credit per 10-minute session

### Salary Intelligence
- [ ] `GET /api/salary` - Get salary data
- [ ] Params: title, location, yoe (years of experience)
- [ ] Aggregate from job postings data
- [ ] Percentile calculations
- [ ] Negotiation tips generation

### Application Q&A
- [ ] `POST /api/qa/answer` - Generate answer
- [ ] Common questions library
- [ ] Context-aware answers (uses profile + job)
- [ ] 0.5 credits per answer

### Analytics Dashboard
- [ ] `GET /api/analytics/funnel` - Application funnel
- [ ] `GET /api/analytics/trends` - Time trends
- [ ] `GET /api/analytics/insights` - AI insights
- [ ] Calculate response rates, interview rates

### UI Components
- [ ] InterviewPrepView.tsx
- [ ] PracticeChat.tsx (interview simulation)
- [ ] PracticeQuestion.tsx
- [ ] ResponseFeedback.tsx
- [ ] PracticeSummary.tsx
- [ ] SalaryChart.tsx
- [ ] SalaryComparison.tsx
- [ ] NegotiationTips.tsx
- [ ] QAHelper.tsx
- [ ] AnalyticsDashboard.tsx
- [ ] FunnelChart.tsx
- [ ] InsightCard.tsx

### Pages
- [ ] `/dashboard/interview-prep/[id]` - View prep
- [ ] `/dashboard/interview-prep/[id]/practice` - Practice mode
- [ ] `/dashboard/salary` - Salary intelligence
- [ ] `/dashboard/analytics` - Analytics dashboard

## Key Files to Create

```
app/(dashboard)/interview-prep/
  [id]/
    page.tsx
    practice/page.tsx
  _components/
    PrepOverview.tsx
    QuestionList.tsx
    STARSuggestions.tsx
    PracticeChat.tsx
    ResponseFeedback.tsx
    PracticeSummary.tsx
    
app/(dashboard)/salary/
  page.tsx
  _components/
    SalaryChart.tsx
    SalaryByStage.tsx
    NegotiationTips.tsx
    OfferComparison.tsx
    
app/(dashboard)/analytics/
  page.tsx
  _components/
    FunnelChart.tsx
    TrendChart.tsx
    InsightCard.tsx
    ResumePerformance.tsx
    
app/api/interview-prep/
  route.ts
  [id]/route.ts
  [id]/practice/
    start/route.ts
    respond/route.ts
    end/route.ts
    
app/api/salary/
  route.ts
  
app/api/qa/
  answer/route.ts
  
app/api/analytics/
  funnel/route.ts
  trends/route.ts
  insights/route.ts

lib/ai/prompts/
  interview-question.ts
  evaluate-response.ts
  qa-answer.ts
```

## Practice Question Prompt

```typescript
const QUESTION_PROMPT = `
Generate interview question.

ROLE: {job_title} at {company}
TYPE: {type} (behavioral/technical/case)
PREVIOUS: {previous_questions}
CULTURE: {cultural_keywords}

Return JSON:
{
  question: "",
  category: "leadership|conflict|failure|technical",
  what_theyre_testing: "",
  suggested_star_tags: []
}
`;
```

## Evaluate Response Prompt

```typescript
const EVALUATE_PROMPT = `
Evaluate interview response.

QUESTION: {question}
RESPONSE: {response}
USER'S STAR STORIES: {stories}

Return JSON:
{
  star_score: 1-10,
  strengths: [],
  improvements: [],
  missing_elements: [],
  suggested_addition: "",
  relevant_story_hint: ""
}
`;
```

## Analytics Calculations

```typescript
// Funnel
const funnel = {
  applied: count where status != 'saved',
  responded: count where status not in ('applied', 'ghosted'),
  interviewed: count where status in ('phone','technical','onsite','offer'),
  offered: count where status = 'offer',
};

// Rates
response_rate = responded / applied;
interview_rate = interviewed / responded;
offer_rate = offered / interviewed;
```

## Tests
- [ ] Interview prep generates correctly
- [ ] Practice questions appropriate to type
- [ ] Response evaluation provides feedback
- [ ] Salary data aggregates correctly
- [ ] Q&A answers use context
- [ ] Analytics calculate accurately

## Done When
- [ ] Can generate full interview prep
- [ ] Can practice with AI interviewer
- [ ] Get feedback on responses
- [ ] See salary intelligence
- [ ] Get help with application questions
- [ ] View job search analytics
- [ ] All tests passing
