# BulletPro Build Skill

Project-specific instructions for building BulletPro features.

## Quick Start

1. Read this file first
2. Read `EXISTING.md` to understand what's built
3. Read current phase file (PHASE0.md, PHASE1.md, etc.)
4. Follow phase-manager skill protocol

## File Index

| File | When to Read | Size |
|------|--------------|------|
| `EXISTING.md` | Start of project | ~100 lines |
| `PHASE0.md` | When doing Phase 0 | ~80 lines |
| `PHASE1.md` | When doing Phase 1 | ~80 lines |
| `PHASE2.md` | When doing Phase 2 | ~80 lines |
| `PHASE3.md` | When doing Phase 3 | ~80 lines |
| `PHASE4.md` | When doing Phase 4 | ~80 lines |
| `PHASE5.md` | When doing Phase 5 | ~80 lines |
| `PHASE6.md` | When doing Phase 6 | ~80 lines |
| `SCHEMA_ADDITIONS.sql` | When doing DB work | ~150 lines |
| `PROMPTS.ts` | When doing AI work | ~200 lines |
| `CONVENTIONS.md` | Reference as needed | ~50 lines |

## DO NOT

- ❌ Read all phase files at once
- ❌ Rebuild existing features (see EXISTING.md)
- ❌ Change auth, payments, or credit deduction logic
- ❌ Modify the landing page design
- ❌ Change Stripe webhook handling

## Project Context

**Stack:** Next.js 14+, TypeScript, Tailwind, Supabase, Stripe, Gemini AI, Resend

**Folder Structure:**
```
app/
  (auth)/         # Auth pages
  (dashboard)/    # Dashboard pages  
  api/            # API routes
lib/
  supabase/       # Supabase client
  stripe/         # Stripe utilities
  ai/             # AI generation (Gemini)
  email/          # Resend emails
types/            # TypeScript types
database/         # SQL migrations
```

## Current Phase

Check with user which phase to start. Typical flow:
```
Phase 0: Foundation (Profile, Metric Mining, Credits update)
Phase 1: Intelligence (Copilot, Research, Job Discovery)
Phase 2: Job Packs (ATS, Tailor-Diff, Cultural)
Phase 3: Tracking (Applications, Stages, Memory Bank)
Phase 4: Interview (Practice, Salary, Q&A)
Phase 5: Extension (Chrome extension)
Phase 6: Growth (Public tools, Referrals, SEO)
Phase 7: Polish & Launch
```

## After Each Phase

Follow phase-manager skill protocol:
1. Show completion summary
2. Show token usage estimate
3. Wait for approval before continuing
