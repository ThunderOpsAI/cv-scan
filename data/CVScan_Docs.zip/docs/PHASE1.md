# Phase 1: Intelligence Core
**Duration:** 5-6 days | **Commit Tag:** `v0.2.0-intelligence`

## Objective
Build Job Search Copilot, Company Research Agent, and Job Discovery system.

## Tasks

### Database
- [ ] Create `conversations` table
- [ ] Create `messages` table
- [ ] Create `company_cache` table (7 day TTL)
- [ ] Create `saved_searches` table
- [ ] Create `discovered_jobs` table
- [ ] Add indexes for performance

### Copilot Chat
- [ ] `POST /api/copilot/chat` - Send message (streaming)
- [ ] `GET /api/copilot/conversations` - List conversations
- [ ] `GET /api/copilot/conversations/[id]` - Get conversation
- [ ] Context builder (loads profile + applications)
- [ ] Command detection (score, find, research, prep, practice)
- [ ] Credit charging per conversation (0.5 credits)

### Company Research
- [ ] `GET /api/company/[name]` - Get/generate research
- [ ] `POST /api/company/[name]/refresh` - Force refresh
- [ ] Research prompt (uses web search)
- [ ] Cache with 7 day TTL
- [ ] 1 credit per research

### Job Discovery
- [ ] Adzuna API integration (`lib/jobs/adzuna.ts`)
- [ ] `GET /api/jobs/discover` - Search jobs
- [ ] `POST /api/jobs/searches` - Create saved search
- [ ] `GET /api/jobs/searches` - List saved searches
- [ ] Job matching algorithm (score vs profile)
- [ ] Daily digest email template
- [ ] Cron job for daily digest

### UI Components
- [ ] CopilotChat.tsx (chat interface with streaming)
- [ ] CopilotMessage.tsx (message bubble)
- [ ] CompanyBrief.tsx (research display)
- [ ] JobDiscoveryList.tsx
- [ ] SavedSearchForm.tsx
- [ ] JobCard.tsx (with match score)

### Pages
- [ ] `/dashboard/copilot` - Chat interface
- [ ] `/dashboard/jobs` - Job discovery
- [ ] `/dashboard/jobs/searches` - Saved searches

## Key Files to Create

```
app/(dashboard)/copilot/
  page.tsx
  _components/
    CopilotChat.tsx
    CopilotMessage.tsx
    CommandSuggestions.tsx
    
app/(dashboard)/jobs/
  page.tsx
  searches/page.tsx
  _components/
    JobCard.tsx
    JobList.tsx
    SavedSearchForm.tsx
    
app/api/copilot/
  chat/route.ts (streaming)
  conversations/route.ts
  conversations/[id]/route.ts
  
app/api/company/
  [name]/route.ts
  
app/api/jobs/
  discover/route.ts
  searches/route.ts

lib/jobs/
  adzuna.ts
  matching.ts
  
lib/ai/prompts/
  company-research.ts
  copilot-system.ts
  
lib/email/templates/
  daily-digest.tsx
```

## Copilot System Prompt

```typescript
const COPILOT_SYSTEM = `
You are a job search assistant. You have access to:
- User's profile: {profile_summary}
- Their applications: {applications_summary}
- Commands: score, find, research, prep, practice, draft

Respond helpfully and concisely. When user wants action, confirm credits first.
`;
```

## Company Research Prompt

```typescript
const RESEARCH_PROMPT = `
Research {company} and return JSON:
{
  overview: { description, founded, hq, employees, industry },
  funding: { stage, raised, valuation },
  culture: { glassdoor_rating, pros, cons },
  interview: { difficulty, process, common_questions },
  news: [{ title, date, summary }]
}
Use web search. Return null for unavailable data.
`;
```

## Tests
- [ ] Copilot responds with context
- [ ] Company research caches correctly
- [ ] Adzuna returns jobs
- [ ] Job matching scores accurately
- [ ] Saved searches persist
- [ ] Daily digest email renders

## Done When
- [ ] Can chat with Copilot about job search
- [ ] Company research generates and caches
- [ ] Job discovery shows matched jobs
- [ ] Saved searches send daily digests
- [ ] All tests passing
