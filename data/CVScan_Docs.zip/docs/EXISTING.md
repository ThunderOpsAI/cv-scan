# Existing Features - DO NOT REBUILD

This documents what's already built and working. Do NOT recreate these.

## Project Structure

```
app/
  (auth)/           # Auth pages
  (dashboard)/      # Dashboard pages
  api/              # API routes
    stripe/         # Stripe endpoints
    generate/       # AI generation endpoints
database/           # SQL files
docs/               # Documentation
lib/
  supabase/         # Supabase client
  stripe/           # Stripe utilities  
  ai/               # Gemini integration
  email/            # Resend integration
types/              # TypeScript types
public/             # Static assets
```

## Authentication ✅
- NextAuth with Google OAuth
- Session management
- Protected routes
- **Do not modify:** `lib/auth/`, `app/(auth)/`

## Database ✅
- Supabase PostgreSQL connected
- Row Level Security enabled
- **Do not modify:** `lib/supabase/client.ts`

### Existing Tables
```sql
users (
  id UUID PRIMARY KEY,
  email TEXT,
  name TEXT,
  credits INTEGER DEFAULT 3,
  created_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ
)
-- Plus NextAuth tables (accounts, sessions, verification_tokens)
```

### Existing Functions (in supabase-functions.sql)
```sql
-- DO NOT MODIFY THESE
add_credits(p_user_id, p_amount, p_type, p_description, p_metadata)
deduct_credit(p_user_id, p_amount, p_type, p_description)
```

## Payments ✅
- Stripe Checkout integration
- 3 credit packages:
  - Starter: $4.99 → 15 credits
  - Popular: $9.99 → 25 credits  
  - Pro: $17.99 → 50 credits
- Webhook handling for payment completion
- Auto credit fulfillment
- **Do not modify:** `app/api/stripe/`, `lib/stripe/`

## AI Generation ✅
- Gemini API integration
- Bullet point generation (1 credit)
- Cover letter generation (2 credits)
- Located: `lib/ai/`, `app/api/generate/`

## Email ✅
- Resend integration
- Welcome email (on signup)
- Payment receipt
- Low credit notification
- **Do not modify:** `lib/email/`

## Landing Page ✅
- Professional design (dark blue gradient)
- "Turn Job Duties Into Powerful Resume Bullets"
- Before/after examples
- Pricing section
- "Try Free - 3 Credits" CTA
- **Do not modify design**, only add new sections

## Dashboard ✅
- Credit balance display
- Basic bullet generation interface
- Located: `app/(dashboard)/`

---

## Integration Patterns

### Using Credits (ALWAYS use existing functions)
```typescript
import { deductCredit } from '@/lib/supabase/credits';

const result = await deductCredit(
  userId,
  2,           // amount
  'job_pack',  // type  
  'Description of what was purchased'
);

if (!result.success) {
  return { error: 'Insufficient credits' };
}
```

### Using Auth
```typescript
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

const session = await getServerSession(authOptions);
if (!session?.user?.id) {
  return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
}
const userId = session.user.id;
```

### Using Supabase
```typescript
import { createClient } from '@/lib/supabase/server';

const supabase = createClient();
const { data, error } = await supabase
  .from('table_name')
  .select('*')
  .eq('user_id', userId);
```

### Using AI (Gemini)
```typescript
import { generateWithGemini } from '@/lib/ai/gemini';

const result = await generateWithGemini({
  prompt: 'Your prompt here',
  model: 'flash', // or 'pro'
});
```

---

## What We're ADDING (New Features)

Phase 0-6 add NEW features without modifying existing ones:

| Phase | New Feature | Touches Existing? |
|-------|-------------|-------------------|
| 0 | Profile system | No (new tables) |
| 1 | Copilot, Job discovery | No (new tables) |
| 2 | ATS scanner, Job packs | No (new tables) |
| 3 | Application tracker | No (new tables) |
| 4 | Interview practice | No (new tables) |
| 5 | Browser extension | No (separate codebase) |
| 6 | Public tools, referrals | Adds to landing page |

**Only Phase 6 modifies the landing page** (adds new sections).
