# BulletPro Code Conventions

## File Structure

```
app/
  (auth)/           # Auth pages (login, signup)
  (dashboard)/      # Protected pages
    [feature]/
      page.tsx              # Main page
      _components/          # Feature components
      _actions/             # Server actions
  api/
    [feature]/
      route.ts              # API route
      [id]/route.ts         # Dynamic route
      
lib/
  supabase/         # Supabase client & helpers
  ai/
    gemini.ts       # Gemini client
    prompts/        # Prompt templates
  email/            # Resend helpers
  jobs/             # Job aggregator integrations
  
types/
  [feature].ts      # TypeScript types per feature
```

## API Routes

```typescript
// Always use this pattern
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';

export async function POST(req: NextRequest) {
  try {
    // 1. Auth check
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // 2. Parse body
    const body = await req.json();
    
    // 3. Validate (use zod)
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error }, { status: 400 });
    }

    // 4. Business logic
    const supabase = createClient();
    // ... do stuff

    // 5. Return
    return NextResponse.json({ data });
    
  } catch (error) {
    console.error('[ENDPOINT_NAME]', error);
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}
```

## Credits

```typescript
// Deduct credits using existing function
import { deductCredit } from '@/lib/supabase/credits';

// Before expensive operation
const result = await deductCredit(
  userId,
  2, // amount
  'job_pack', // type
  'Created job pack for Stripe PM role' // description
);

if (!result.success) {
  return NextResponse.json({ error: 'Insufficient credits' }, { status: 402 });
}
```

## AI Calls

```typescript
// Use Flash for most things (cheaper, faster)
import { generateWithGemini } from '@/lib/ai/gemini';

const result = await generateWithGemini({
  prompt: PROMPT_TEMPLATE.replace('{var}', value),
  model: 'flash', // or 'pro' for quality-critical
  responseFormat: 'json', // or 'text'
});

// Always wrap in try/catch
// Always validate JSON responses
```

## Components

```typescript
// Use 'use client' only when needed
// Prefer server components

// Client component pattern
'use client';

import { useState } from 'react';

interface Props {
  initialData: DataType;
  onUpdate: (data: DataType) => Promise<void>;
}

export function MyComponent({ initialData, onUpdate }: Props) {
  const [data, setData] = useState(initialData);
  const [loading, setLoading] = useState(false);
  
  // ... component logic
}
```

## Database

```typescript
// Always use typed queries
const { data, error } = await supabase
  .from('applications')
  .select('*')
  .eq('user_id', userId)
  .order('created_at', { ascending: false });

// Handle errors
if (error) {
  console.error('[FUNCTION_NAME]', error);
  throw new Error('Database error');
}
```

## Types

```typescript
// types/profile.ts
export interface Profile {
  id: string;
  full_name: string | null;
  headline: string | null;
  location: {
    city?: string;
    state?: string;
    country?: string;
  } | null;
  // ... etc
}

// Use Supabase generated types when available
import { Database } from '@/types/supabase';
type Profile = Database['public']['Tables']['profiles']['Row'];
```

## Error Handling

```typescript
// API routes: return JSON errors
return NextResponse.json({ error: 'Message' }, { status: 400 });

// Client: use try/catch with toast
try {
  await doThing();
  toast.success('Done!');
} catch (error) {
  toast.error('Something went wrong');
}
```

## Naming

- Files: kebab-case (`job-pack-wizard.tsx`)
- Components: PascalCase (`JobPackWizard`)
- Functions: camelCase (`createJobPack`)
- Constants: UPPER_SNAKE (`MAX_FREE_SCANS`)
- Types: PascalCase (`JobPack`)
- Database: snake_case (`job_packs`)

## Commits

```bash
feat: add [feature]        # New feature
fix: resolve [issue]       # Bug fix  
refactor: improve [area]   # Code improvement
test: add tests for [x]    # Tests
docs: update [doc]         # Documentation
chore: [task]              # Maintenance
```

## Don't

- ❌ Use `any` without comment explaining why
- ❌ Leave console.log in production code
- ❌ Skip error handling
- ❌ Hardcode secrets (use env vars)
- ❌ Rebuild existing features (check EXISTING.md)
- ❌ Skip TypeScript types
