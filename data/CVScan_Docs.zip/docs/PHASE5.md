# Phase 5: Browser Extension
**Duration:** 5-6 days | **Commit Tag:** `v0.6.0-extension`

## Objective
Build Chrome extension for one-click job scanning and saving.

## Tasks

### Extension Setup
- [ ] Create `extension/` directory in project root
- [ ] manifest.json (Manifest V3)
- [ ] Extension icons (16, 48, 128px)
- [ ] Build script for extension

### Auth Token Management
- [ ] Store auth token in chrome.storage
- [ ] Token refresh mechanism
- [ ] Login redirect if not authenticated

### Content Scripts (Job Detection)
- [ ] LinkedIn job page detector
- [ ] Indeed job page detector
- [ ] Glassdoor job page detector
- [ ] Greenhouse job page detector
- [ ] Lever job page detector
- [ ] Generic career page fallback
- [ ] Job data extraction (title, company, description)

### Extension Popup
- [ ] React popup UI
- [ ] Show detected job info
- [ ] Quick ATS score display
- [ ] Match score from profile
- [ ] Action buttons (Score, Save, Create Pack)
- [ ] Credit balance display
- [ ] Link to full web app

### Background Service Worker
- [ ] Handle messages from content scripts
- [ ] API communication with BulletPro backend
- [ ] Cache management

### Web App Integration
- [ ] `POST /api/extension/score` - Quick score for extension
- [ ] `POST /api/extension/save` - Save job to tracker
- [ ] `POST /api/extension/sync` - Sync status updates
- [ ] Auth token validation endpoint

## Extension Directory Structure

```
extension/
  manifest.json
  
  icons/
    icon16.png
    icon48.png
    icon128.png
    
  popup/
    index.html
    popup.tsx
    popup.css
    components/
      JobInfo.tsx
      ScoreDisplay.tsx
      ActionButtons.tsx
      LoginPrompt.tsx
      
  content-scripts/
    detector.ts
    extractors/
      linkedin.ts
      indeed.ts
      glassdoor.ts
      greenhouse.ts
      lever.ts
      generic.ts
      
  background/
    service-worker.ts
    api.ts
    auth.ts
    
  utils/
    storage.ts
    messaging.ts
    
  build/
    (compiled output)
```

## manifest.json

```json
{
  "manifest_version": 3,
  "name": "BulletPro - ATS Resume Scanner",
  "version": "1.0.0",
  "description": "Instantly score your resume match for any job posting",
  
  "permissions": [
    "storage",
    "activeTab"
  ],
  
  "host_permissions": [
    "https://www.linkedin.com/*",
    "https://www.indeed.com/*",
    "https://www.glassdoor.com/*",
    "https://boards.greenhouse.io/*",
    "https://jobs.lever.co/*"
  ],
  
  "action": {
    "default_popup": "popup/index.html",
    "default_icon": {
      "16": "icons/icon16.png",
      "48": "icons/icon48.png",
      "128": "icons/icon128.png"
    }
  },
  
  "content_scripts": [
    {
      "matches": [
        "https://www.linkedin.com/jobs/*",
        "https://www.indeed.com/viewjob*",
        "https://www.glassdoor.com/job-listing/*",
        "https://boards.greenhouse.io/*",
        "https://jobs.lever.co/*"
      ],
      "js": ["content-scripts/detector.js"]
    }
  ],
  
  "background": {
    "service_worker": "background/service-worker.js"
  },
  
  "icons": {
    "16": "icons/icon16.png",
    "48": "icons/icon48.png",
    "128": "icons/icon128.png"
  }
}
```

## Site Detectors

```typescript
// content-scripts/extractors/linkedin.ts
export const linkedinExtractor = {
  matches: /linkedin\.com\/jobs/,
  selectors: {
    title: '.job-details-jobs-unified-top-card__job-title',
    company: '.job-details-jobs-unified-top-card__company-name',
    location: '.job-details-jobs-unified-top-card__bullet',
    description: '.jobs-description__content'
  },
  extract: (doc: Document) => ({
    title: doc.querySelector(selectors.title)?.textContent?.trim(),
    company: doc.querySelector(selectors.company)?.textContent?.trim(),
    // ...
  })
};
```

## Popup Communication

```typescript
// popup/popup.tsx
const [jobData, setJobData] = useState(null);

useEffect(() => {
  // Get job data from content script
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, { type: 'GET_JOB_DATA' }, (response) => {
      setJobData(response);
    });
  });
}, []);

const handleScore = async () => {
  const result = await chrome.runtime.sendMessage({
    type: 'SCORE_JOB',
    data: jobData
  });
  setScore(result.score);
};
```

## API Endpoints for Extension

```typescript
// app/api/extension/score/route.ts
// Quick score endpoint - returns score + top gaps only
// Used by extension popup for instant feedback

// app/api/extension/save/route.ts  
// Save job to applications table
// Creates application with status='saved'
```

## Tests
- [ ] Extension loads in Chrome
- [ ] Detects jobs on LinkedIn
- [ ] Detects jobs on Indeed
- [ ] Detects jobs on Greenhouse/Lever
- [ ] Popup shows job info
- [ ] Score API returns quickly
- [ ] Save creates application
- [ ] Auth token persists

## Build Process

```bash
# In extension directory
npm run build  # Compiles TS, bundles for Chrome

# Creates extension/build/ with:
# - manifest.json
# - popup/index.html + bundle.js
# - content-scripts/detector.js
# - background/service-worker.js
# - icons/
```

## Done When
- [ ] Extension installable in Chrome
- [ ] Detects jobs on major sites
- [ ] Shows match score in popup
- [ ] Can save jobs to tracker
- [ ] Syncs with web app
- [ ] Ready for Chrome Web Store
- [ ] All tests passing
